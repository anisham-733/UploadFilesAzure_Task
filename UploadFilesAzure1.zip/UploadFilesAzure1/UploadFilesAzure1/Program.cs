﻿using System;
using System.Collections.Generic;
using System.IO;
using Azure.Storage.Blobs;
using System.Text;

namespace UploadFilesAzure1
{
    internal class Program
    {
        static string connectionString = "DefaultEndpointsProtocol=https;AccountName=development123;AccountKey=Y4lqO5uFtGmTchA9ehtyPqK6aJ8PNeCw0trfywan2AiVhaFXgM0j4i4/eJnSRLJ7MP49bSSTtdAH+ASt8Ov0Aw==;EndpointSuffix=core.windows.net";
        static string containerName = "development";
        static string localFilePath = "C:\\Users\\AnishaMahajan\\Documents\\C#Image.png";
        static string localFolderPath = "C:\\Users\\AnishaMahajan\\Documents\\AzureDir\\Anisha\\C#Image.png";
        public static void Main(string[] args)
        {
            BlobServiceClient blobServiceClient = new BlobServiceClient(connectionString);
            //            
            var containerName1 = "anisha";

            //To create NEW CONTAINER
            //blobServiceClient.CreateBlobContainer(containerName1);

            //Create a new BlobContainerClient object by appending blobContainerName to the end of Uri
            BlobContainerClient blobContainerClient = blobServiceClient.GetBlobContainerClient(containerName1);

            Console.WriteLine("Uploading to Blob storage as blob:\n\t {0}\n", blobServiceClient.Uri);

            //string filename = Path.GetFileName(localFilePath);
            //BlobClient blobClient = blobContainerClient.GetBlobClient(filename);
            //blobClient.Upload(localFilePath,true);

            //string foldername = Path.GetFileName(Path.GetDirectoryName(localFolderPath));
            //Create a new BlobClient object by appending blobName to the end of Uri

            //explicitly passing blob name .
            //BlobClient blobClient = blobContainerClient.GetBlobClient("Anisha\\C#Image.png");
            //blobClient.Upload(localFolderPath, true);

            //fetching Blob name through the localfilepath.
            string lastfolderName = Path.GetFileName(Path.GetDirectoryName(localFolderPath));//Anisha
            string filename = Path.GetFileName(localFolderPath);
            string finalPath = $"{lastfolderName}\\{filename}";
            Console.WriteLine(finalPath);
            BlobClient blobClient = blobContainerClient.GetBlobClient(finalPath);
            blobClient.UploadAsync(localFolderPath, true);
                                                                                          

            // PRACTICEE
            //string path = "C:/folder1/folder2/file.txt";
            //string lastFolderName = Path.GetFileName(Path.GetDirectoryName(path));
            //Console.WriteLine(lastFolderName);
            //string l = Path.GetFileName(path);
            //Console.WriteLine($"{lastFolderName}\\{l}");

        }
    }
}